$(document).ready(function(){
				
    $("#Arrogate").click(function(){
        $(this).slideToggle();
    });

    $('h1').click(function(){
    $('#Arrogate').slideToggle();
    });

    $('p, h3, h5').hover(function() {
        $(this).css('color', 'white');
        }, function() {
            $(this).css('color', 'black');
    });
    $('h4').hover(function() {
        $(this).css('color', 'red');
        }, function() {
            $(this).css('color', 'black');
    });

  });